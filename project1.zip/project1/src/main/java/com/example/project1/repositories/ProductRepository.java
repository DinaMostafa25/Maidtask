package com.example.project1.repositories;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.project1.entities.Device;

public interface ProductRepository extends JpaRepository<Device, Long> {
    
}