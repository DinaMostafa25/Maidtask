package com.example.project1.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.example.project1.entities.Device;
import com.example.project1.repositories.ProductRepository;
import com.example.project1.services.ApiServices;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/devices/")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ApiServices apiServices;

    // Get all devices
    @GetMapping
    public ResponseEntity<List<Device>> getAllProducts() {
        List<Device> productList = productRepository.findAll();
        return new ResponseEntity<>(productList, HttpStatus.OK);
    }

    // Get device by ID
    @GetMapping("/{id}")
    public ResponseEntity<Device> getProductById(@PathVariable("id") Long id) {
        Optional<Device> product = productRepository.findById(id);
        if (product.isPresent()) {
            return new ResponseEntity<>(product.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Create a new device
    @PostMapping
    public ResponseEntity<Device> createProduct(@RequestBody Device product) {
        Device newProduct = productRepository.save(product);
        return new ResponseEntity<>(newProduct, HttpStatus.CREATED);
    }
    // Predict device price by id
    @PostMapping("/predict/{id}")
    public ResponseEntity<Integer> predictProductPriceById(@PathVariable("id") Long id) {
        Optional<Device> product = productRepository.findById(id);
        if (product.isPresent()) {
            return new ResponseEntity<>(apiServices.callApi(product.get()), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

    }
   

}
