package com.example.project1.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.project1.entities.Device;


@Service
public class ApiServices {
    
    @Autowired

    private RestTemplate restTemplate;

    public int callApi(Device device) {
        String url = "http://localhost:5000/predict"; 
        return restTemplate.postForObject(url, device, Integer.class); 
       
    }
}
