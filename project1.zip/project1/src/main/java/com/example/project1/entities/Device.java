package com.example.project1.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table

public class Device {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int batteryPower;
    private int blue;
    private double clockSpeed;
    private int dualSim;
    private double fc;
    @Column(name = "four_g")
    private double fourG;
    private double intMemory;
    private double mDep;
    private double mobileWt;
    private double nCores;
    private double pc;
    private double pxHeight;
    private double pxWidth;
    private double ram;
    @Column(name = "sc_h")
    private double scH;
    @Column(name = "sc_w")
    private double scW;
    private int talkTime;
    @Column(name = "three_g")
    private int threeG;
    private int touchScreen;
    private int wifi;
    

    // Getters and setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getBatteryPower() {
        return batteryPower;
    }

    public void setBatteryPower(int batteryPower) {
        this.batteryPower = batteryPower;
    }

    public int getBlue() {
        return blue;
    }

    public void setBlue(int blue) {
        this.blue = blue;
    }

    public double getClockSpeed() {
        return clockSpeed;
    }

    public void setClockSpeed(double clockSpeed) {
        this.clockSpeed = clockSpeed;
    }

    public int getDualSim() {
        return dualSim;
    }

    public void setDualSim(int dualSim) {
        this.dualSim = dualSim;
    }

    public double getFc() {
        return fc;
    }

    public void setFc(double fc) {
        this.fc = fc;
    }

    public double getFourG() {
        return fourG;
    }

    public void setFourG(double fourG) {
        this.fourG = fourG;
    }

    public double getIntMemory() {
        return intMemory;
    }

    public void setIntMemory(double intMemory) {
        this.intMemory = intMemory;
    }

    public double getmDep() {
        return mDep;
    }

    public void setmDep(double mDep) {
        this.mDep = mDep;
    }

    public double getMobileWt() {
        return mobileWt;
    }

    public void setMobileWt(double mobileWt) {
        this.mobileWt = mobileWt;
    }

    public double getnCores() {
        return nCores;
    }

    public void setnCores(double nCores) {
        this.nCores = nCores;
    }

    public double getPc() {
        return pc;
    }

    public void setPc(double pc) {
        this.pc = pc;
    }

    public double getPxHeight() {
        return pxHeight;
    }

    public void setPxHeight(double pxHeight) {
        this.pxHeight = pxHeight;
    }

    public double getPxWidth() {
        return pxWidth;
    }

    public void setPxWidth(double pxWidth) {
        this.pxWidth = pxWidth;
    }

    public double getRam() {
        return ram;
    }

    public void setRam(double ram) {
        this.ram = ram;
    }

    public double getScH() {
        return scH;
    }

    public void setScH(double scH) {
        this.scH = scH;
    }

    public double getScW() {
        return scW;
    }

    public void setScW(double scW) {
        this.scW = scW;
    }

    public int getTalkTime() {
        return talkTime;
    }

    public void setTalkTime(int talkTime) {
        this.talkTime = talkTime;
    }

    public int getThreeG() {
        return threeG;
    }

    public void setThreeG(int threeG) {
        this.threeG = threeG;
    }

    public int getTouchScreen() {
        return touchScreen;
    }

    public void setTouchScreen(int touchScreen) {
        this.touchScreen = touchScreen;
    }

    public int getWifi() {
        return wifi;
    }

    public void setWifi(int wifi) {
        this.wifi = wifi;
    }

}

